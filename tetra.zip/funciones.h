float calcularDistancia(float x1, float y1, float z1, float x2, float y2, float z2 );
float calcularPerimetro(float puntos[4][3], float *a, float *b, float *c, float *d, float *e, float*f);
float calcularArea(float a, float b, float c);
float calcularVolumen(float puntos[4][3],float a, float *h);
