#include <stdio.h>
#include <math.h>
#include "funciones.h"




int main (int argc, char *argv[]) {
 
    float puntos[4][3]={{0,0,0,}, {3,0,0}, {0,0,3}, {1,7,1}};
    float per,a,b,c,d,e,f,h;

    float perimentro = calcularPerimetro(puntos,&a,&b,&c,&d,&e,&f);
    float area1= calcularArea(a,b,c);
    float area2= calcularArea(b,d,e);
    float area3= calcularArea(a,e,f);
    float area4= calcularArea(e,f,a);

    float areasuperficial= area1+area2+area3+area4;

    float volumen = calcularVolumen(puntos, a, &h);

    printf("el perimetro es : %f\n", perimentro);
    printf("el area superficial es : %f\n", areasuperficial);

    printf("el volumen es : %f\n", volumen);

 
    return 0;
}

